from ._random_name import get_random_name
from ._common import (
    as_numpy,
    as_tensor,
    call,
    instantiate,
    set_random_seed,
)


__version__ = "0.1.5"

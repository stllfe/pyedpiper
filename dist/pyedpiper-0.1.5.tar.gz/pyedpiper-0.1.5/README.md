# Pyedpiper
It's a small (or not really) ML-related set of handy tools to compliment PyTorch-Lightning.
Key aspects I wanted to address were flexibility and extendability of PyTorch-Lightning models and pipelines. 
Ultimate goal is absolutely hands-free experiment tweeking using only configuration files. 


  
